const serverData = new Map();

module.exports = serverData;